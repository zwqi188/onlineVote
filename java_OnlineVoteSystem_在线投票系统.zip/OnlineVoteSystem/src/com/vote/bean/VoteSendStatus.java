package com.vote.bean;

public class VoteSendStatus {
	private int userid;
	private int activetypeid;
	private int isvote;
	private int issend;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public int getActivetypeid() {
		return activetypeid;
	}

	public void setActivetypeid(int activetypeid) {
		this.activetypeid = activetypeid;
	}

	public int getIsvote() {
		return isvote;
	}

	public void setIsvote(int isvote) {
		this.isvote = isvote;
	}

	public int getIssend() {
		return issend;
	}

	public void setIssend(int issend) {
		this.issend = issend;
	}

	public VoteSendStatus(int userid, int activetypeid, int isvote, int issend) {
		super();
		this.userid = userid;
		this.activetypeid = activetypeid;
		this.isvote = isvote;
		this.issend = issend;
	}

	public VoteSendStatus() {
		super();
	}
}
