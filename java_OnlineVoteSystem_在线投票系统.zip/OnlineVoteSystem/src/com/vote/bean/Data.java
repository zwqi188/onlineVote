package com.vote.bean;

public class Data {
	private int id;
	private int votenum;
	private String picture;
	private String detail;
	private String name;
	private int userid;
	private int activetypeid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getVotenum() {
		return votenum;
	}

	public void setVotenum(int votenum) {
		this.votenum = votenum;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public int getActivetypeid() {
		return activetypeid;
	}

	public void setActivetypeid(int activetypeid) {
		this.activetypeid = activetypeid;
	}

	public Data(int id, int votenum, String picture, String detail,String name, int userid, int activetypeid) {
		super();
		this.id = id;
		this.votenum = votenum;
		this.picture = picture;
		this.detail = detail;
		this.name = name;
		this.userid = userid;
		this.activetypeid = activetypeid;
	}

	public Data() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Data(int id, String picture, String detail, String name) {
		super();
		this.id = id;
		this.picture = picture;
		this.detail = detail;
		this.name = name;
	}
	

}
