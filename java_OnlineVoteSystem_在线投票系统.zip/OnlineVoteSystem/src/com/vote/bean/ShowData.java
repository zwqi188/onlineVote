package com.vote.bean;

import java.io.Serializable;

public class ShowData implements Serializable {
	private int id;
	private int votenum;
	private String picture;
	private String detail;
	private String dataname;
	private String username;
	private String activetypename;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getVotenum() {
		return votenum;
	}

	public void setVotenum(int votenum) {
		this.votenum = votenum;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getActivetypename() {
		return activetypename;
	}

	public void setActivetypename(String activetypename) {
		this.activetypename = activetypename;
	}

	public ShowData(int id, int votenum, String picture, String detail,String dataname, String username, String activetypename) {
		super();
		this.id = id;
		this.votenum = votenum;
		this.picture = picture;
		this.detail = detail;
		this.dataname = dataname;
		this.username = username;
		this.activetypename = activetypename;
	}

	public ShowData() {
		super();
	}

	public String getDataname() {
		return dataname;
	}

	public void setDataname(String dataname) {
		this.dataname = dataname;
	}

}
