package com.vote.upload;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class FileUploadServlet
 */
@WebServlet("/FileUploadServlet.do")
public class FileUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FileUploadServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("进来了-------");
		//判断传递的是否是文件类型
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if(isMultipart){
			System.out.println("又进来了--------");
			// Create a factory for disk-based file items
			DiskFileItemFactory factory = new DiskFileItemFactory();

			// Configure a repository (to ensure a secure temp location is used)
			ServletContext servletContext = this.getServletConfig().getServletContext();
			//获取临时文件夹
			File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
			factory.setRepository(repository);

			// Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setHeaderEncoding("UTF-8");

			// Parse the request
			try {
				//解析  request
				List<FileItem> items = upload.parseRequest(request);
				
				Iterator<FileItem> iter = items.iterator();
				while (iter.hasNext()) {
				    FileItem item = iter.next();

				    if (item.isFormField()) {
				    	System.out.println("不是文件.........");
				        System.out.println(item.getFieldName());
				        System.out.println(item.getString("UTF-8"));
				    } else {
				    	System.out.println("是文件.........");
				    	
				    	String fieldName = item.getFieldName();
				        String fileName = item.getName();   //文件名
				        String contentType = item.getContentType();  // 文件类型
				        boolean isInMemory = item.isInMemory();   
				        long sizeInBytes = item.getSize();   //文件大小
				        System.out.println(fieldName+" "+fileName+" "+contentType+" "+isInMemory+" "+sizeInBytes);
				        //String  savepath  = servletContext.getRealPath("//")+File.separator+"upload";
				        
				        //int idx = fileName.lastIndexOf(".");
						//String subfix = fileName.substring(idx);
						//
						//String fileName2 = new Date().getTime() + subfix;
				        
				        String savepath = "C:"+File.separator+"upload";
				        System.out.println("savepath----"+savepath);
				        File filefolder = new File(savepath);
				        if(!filefolder.exists()){
				        	filefolder.mkdirs();
				        }
				        //完整的存储文件名
							//item.getName事完整路径名
						
						
						int idx = item.getName().lastIndexOf(".");
						String subfix = item.getName().substring(idx);
						String fileName2 = new Date().getTime() + subfix;
						//File tempfile=new File(item.getName());
				        //String filefullpath = savepath+File.separator+tempfile.getName();
						String filefullpath = savepath+File.separator+fileName2;
			        	System.out.println(filefullpath);
			        	File uploadedFile = new File(filefullpath);
			            item.write(uploadedFile);
				        System.out.println(savepath);
				        
				        response.setContentType("text/html;charset=UTF-8");
				        PrintWriter out = response.getWriter();
				        out.println("<script>parent.fun('/upload/"+fileName2+"');</script>");
				        
				        
				    }
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else{
			System.out.println("nonononononononononononononononononononononononono");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
