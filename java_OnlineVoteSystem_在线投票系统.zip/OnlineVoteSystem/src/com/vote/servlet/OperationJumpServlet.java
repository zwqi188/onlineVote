package com.vote.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vote.bean.ShowData;
import com.vote.dao.GetBasicDataDao;
import com.vote.dao.impl.GetBasicDataDaoImpl;

/**
 * Servlet implementation class OperationJumpServlet
 */
@WebServlet("/OperationJumpServlet.do")
public class OperationJumpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	GetBasicDataDao gbdao = null;
	List<ShowData> listdata = null;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OperationJumpServlet() {
		gbdao = new GetBasicDataDaoImpl();
		listdata = new ArrayList<ShowData>();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String opmethod = request.getParameter("opmethod");
		if(opmethod != null&&opmethod.equals("add")){
			add(request, response);
		}else if(opmethod != null&&opmethod.equals("amend")){
			amend(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	protected void add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String activetypeid = request.getParameter("activetypeid");
		request.getRequestDispatcher(
				"/send.jsp?activename=" + gbdao.getATNameById(new Integer(activetypeid)).getName())
				.forward(request, response);
	}
	
	protected void amend(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//System.out.println("amend");
		int dataid = Integer.parseInt(request.getParameter("dataid"));
		listdata = gbdao.getShowDataByid(dataid);
		request.getSession().setAttribute("listdata", listdata);
		request.getRequestDispatcher("editdata.jsp").forward(request, response);
	}
	

}
