package com.vote.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vote.bean.User;
import com.vote.dao.LoginRegisterDao;
import com.vote.dao.impl.LoginRegisterDaoImpl;

/**
 * Servlet implementation class LoginRegisterServlet
 */
@WebServlet("/LoginRegisterServlet.do")
public class LoginRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	LoginRegisterDao lrdao = null;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginRegisterServlet() {
		lrdao = new LoginRegisterDaoImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if(action!=null&&action.equals("login")){
			login(request, response);
		}else if(action!=null&&action.equals("register")){
			register(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	protected void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("username");
		String password = request.getParameter("password");
		String checkcode = request.getParameter("checkcode");
		int namecnt = -1;
		for(int i=0;i<lrdao.getAllUser().size();i++){
			if(lrdao.getAllUser().get(i).getName().equals(name)){
				namecnt ++;
			}
		}
		if(namecnt != -1){
			response.getWriter().write("true");
			if(name!=null && password != null){
				User user = lrdao.login(name, password);
				if(user != null){
					if(checkcode!=null&&checkcode.equals(request.getSession().getAttribute("rand"))){
						request.getSession().setAttribute("user", user);
						request.getRequestDispatcher("/GetBasicDataServlet.do?handler=login").forward(request, response);
					}else{
						String msg = "验证码错误";
						request.setAttribute("msg", msg);
						request.getRequestDispatcher("/login.jsp").forward(request, response);
					}
				}else{
					String msg = "密码错误";
					request.setAttribute("msg", msg);
					request.getRequestDispatcher("/login.jsp").forward(request, response);
				}
			}
		}else{
			response.getWriter().write("false");
		}
		
	}
	protected void register(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println(name);
		String email = request.getParameter("email");
		int id = 0;
		if(name!=null&&password!=null&&email!=null){
			if(!lrdao.check(name)){
				if(lrdao.getAllUser().size() != 0){
					id = lrdao.getAllUser().get(0).getId()+1;
				}else{
					id = 1;
				}
				User user = new User(id, name, password, email);
						
				lrdao.register(user);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
			}else{
				String msg = "用户名已经存在";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("/register.jsp").forward(request, response);
			}
		}
	}
}
