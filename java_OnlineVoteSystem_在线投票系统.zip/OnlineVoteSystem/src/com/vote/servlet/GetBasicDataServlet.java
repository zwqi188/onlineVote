package com.vote.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vote.bean.ActiveType;
import com.vote.dao.GetBasicDataDao;
import com.vote.dao.impl.GetBasicDataDaoImpl;
import com.vote.util.PageUtil;

/**
 * Servlet implementation class GetBasicDataServlet
 */
@WebServlet("/GetBasicDataServlet.do")
public class GetBasicDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	GetBasicDataDao gbddao = null;
	// VoteSendDao vsdao = null;
	List<ActiveType> atList = null;


	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetBasicDataServlet() {
		gbddao = new GetBasicDataDaoImpl();
		// vsdao = new VoteSendDaoImpl();
		atList = new ArrayList<ActiveType>();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String handler = request.getParameter("handler");
		if (handler != null && handler.equals("login")) {
			logintomain(request, response);
		} else if (handler != null && handler.equals("showdata")) {
			showdata(request, response);
		} else if (handler != null && handler.equals("myselfdata")) {
			myselfdata(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void logintomain(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String find = request.getParameter("find");
		String page = request.getParameter("page");
		if (page == null) {
			page = "1";
		}
		PageUtil pageUtil = null;
		if(find == null){
			
			request.setAttribute("activetype", gbddao.getAllActiveTypeByPage(new Integer(page), 2));
			// 构建 分页组件
			pageUtil = new PageUtil(gbddao.getAllActiveTypeCount(), "GetBasicDataServlet.do?handler=login",
					new Integer(page), 2);
		}else{
			request.setAttribute("activetype", gbddao.getFindActiveTypeByPage(find, new Integer(page), 2));
			// 构建 分页组件
			pageUtil = new PageUtil(gbddao.getFindActiveTypeCount(find), "GetBasicDataServlet.do?handler=login&find="+find,
					new Integer(page), 2);
		}
		request.setAttribute("pageUtil", pageUtil);
		// request.setAttribute("activetype", gbddao.getAllActiveType());
		request.getRequestDispatcher("/main.jsp?stop=1").forward(request, response);
		
	}

	protected void showdata(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String activetypeid = request.getParameter("activetypeid");
		String page = request.getParameter("page");
		if (page == null) {
			page = "1";
		}
		String find = request.getParameter("find");
		System.out.println(find);
		PageUtil pageUtil = null;
		if(find == null){
			System.out.println("not find");
			request.setAttribute("data", gbddao.getShowDataByPage(new Integer(activetypeid), new Integer(page), 8));
			// 构建 分页组件
			System.out.println(gbddao.getShowDataByName(new Integer(activetypeid)).size());
			pageUtil = new PageUtil(gbddao.getShowDataCount(new Integer(activetypeid)),
					"GetBasicDataServlet.do?activetypeid=" + new Integer(activetypeid) + "&handler=showdata",
					new Integer(page), 8);
		}else{
			System.out.println("find");
			request.setAttribute("data", gbddao.getFindShowDataByPage(find,new Integer(activetypeid), new Integer(page), 8));
			// 构建 分页组件
			//System.out.println(gbddao.getShowDataByName(new Integer(activetypeid)).size());
			pageUtil = new PageUtil(gbddao.getFindShowDataCount(find,new Integer(activetypeid)),
					"GetBasicDataServlet.do?activetypeid=" + new Integer(activetypeid) + "&handler=showdata&find="+find,
					new Integer(page), 8);
		}
		request.setAttribute("pageUtil", pageUtil);
		// request.setAttribute("data", gbddao.getShowDataByName(new
		// Integer(activetypeid)));
		request.setAttribute("active", gbddao.getATNameById(new Integer(activetypeid)));
		request.getRequestDispatcher("/showdata.jsp?activetypeid=" + activetypeid).forward(request, response);
	}

	protected void myselfdata(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("myselfdata");
		String usertableid = request.getParameter("usertableid");
		//Object activename=request.getParameter("activename");
		String find = request.getParameter("find");
		String page = request.getParameter("page");
		if (page == null) {
			page = "1";
		}
		System.out.println(find);
		if(find == null){
			request.setAttribute("data", gbddao.getmyselfShowDataByPage(new Integer(usertableid), new Integer(page), 3));
			// 构建 分页组件
			//System.out.println(gbddao.getmyselfShowDataByName(new Integer(usertableid)).size());
			PageUtil pageUtil = new PageUtil(gbddao.getmyselfShowDataCount(new Integer(usertableid)),
					"GetBasicDataServlet.do?usertableid=" + new Integer(usertableid) + "&handler=myselfdata",
					new Integer(page), 3);

			request.setAttribute("pageUtil", pageUtil);
			
		}else{
			
			request.setAttribute("data", gbddao.getShowDataByidAndName(new Integer(usertableid),find, new Integer(page), 3));
			// 构建 分页组件
			//System.out.println("**"+gbddao.getmyselfShowAndDataCount(4,String.valueOf(activename)));
			PageUtil pageUtil = new PageUtil(gbddao.getmyselfShowAndDataCount(new Integer(usertableid),find),
					"GetBasicDataServlet.do?usertableid=" + new Integer(usertableid) + "&handler=myselfdata&find="+find,
					new Integer(page), 3);

			request.setAttribute("pageUtil", pageUtil);
		}
		
		atList = gbddao.getIsVoteData(new Integer(usertableid));
		request.setAttribute("atList",atList);

		//
		//request.setAttribute("data", gbddao.getShowDataById(userid));
		request.getRequestDispatcher("/percenter.jsp").forward(request, response);
	}

}
