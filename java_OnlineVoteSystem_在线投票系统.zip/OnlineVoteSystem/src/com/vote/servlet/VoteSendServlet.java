package com.vote.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vote.bean.User;
import com.vote.bean.VoteSendStatus;
import com.vote.dao.VoteSendDao;
import com.vote.dao.impl.VoteSendDaoImpl;

/**
 * Servlet implementation class VoteSendServlet
 */
@WebServlet("/VoteSendServlet.do")
public class VoteSendServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VoteSendDao vsdao = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VoteSendServlet() {
		vsdao = new VoteSendDaoImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action != null && action.equals("vote")) {
			vote(request, response);
		} else if (action != null && action.equals("send")) {
			send(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void vote(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String activetypeid = request.getParameter("activetypeid");
		String dataid = request.getParameter("dataid");
		User user = (User) request.getSession().getAttribute("user");
		VoteSendStatus v = vsdao.getVSS(user.getId(), new Integer(activetypeid));
		if (v != null) {
			System.out.println("v  not null");
			if (v.getIsvote() != 1) {
				System.out.println("v.getIsvote()   ===     0");
				// update
				vsdao.amendDataVoteNum(new Integer(dataid)); // 更新 数据表票数
				vsdao.amendVSSVote(user.getId(), new Integer(activetypeid), 1); // 更新该用户对该活动投票状态
			} else {
				String msg = "您已经投过该活动的票了";
				request.setAttribute("msg", msg);
			}
		} else {
			System.out.println("v   null");
			// insert
			vsdao.amendDataVoteNum(new Integer(dataid)); // 更新 数据表票数
			VoteSendStatus vss = new VoteSendStatus(user.getId(), new Integer(activetypeid), 1, 0);
			vsdao.addVSS(vss);
		}
		request.getRequestDispatcher("GetBasicDataServlet.do?activetypeid=" + activetypeid + "&handler=showdata")
				.forward(request, response);
	}

	protected void send(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String activetypeid = request.getParameter("activetypeid");
		User user = (User) request.getSession().getAttribute("user");
		VoteSendStatus v = vsdao.getVSS(user.getId(), new Integer(activetypeid));
		if (v != null) {
			if (v.getIssend() != 1) {
				request.getRequestDispatcher("OperationJumpServlet.do?activetypeid=" + activetypeid+"&opmethod=add").forward(request,
						response);
			} else {
				String msg = "您已经参加过该活动了";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher(
						"GetBasicDataServlet.do?activetypeid=" + activetypeid + "&handler=showdata")
						.forward(request, response);
			}
		} else {
			request.getRequestDispatcher("OperationJumpServlet.do?activetypeid=" + activetypeid+"&opmethod=add").forward(request,
					response);
		}
	}

}
