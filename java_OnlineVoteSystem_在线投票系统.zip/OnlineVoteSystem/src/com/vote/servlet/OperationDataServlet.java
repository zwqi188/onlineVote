package com.vote.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vote.bean.Data;
import com.vote.bean.User;
import com.vote.bean.VoteSendStatus;
import com.vote.dao.GetBasicDataDao;
import com.vote.dao.OperationDataDao;
import com.vote.dao.VoteSendDao;
import com.vote.dao.impl.GetBasicDataDaoImpl;
import com.vote.dao.impl.OperationDataDaoImpl;
import com.vote.dao.impl.VoteSendDaoImpl;

/**
 * Servlet implementation class OperationDataServlet
 */
@WebServlet("/OperationDataServlet.do")
public class OperationDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	GetBasicDataDao gbdao = null;
	OperationDataDao oddao = null;
	VoteSendDao vsdao = null;
	OperationDataDaoImpl oddi = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OperationDataServlet() {
		gbdao = new GetBasicDataDaoImpl();
		oddao = new OperationDataDaoImpl();
		vsdao = new VoteSendDaoImpl();
		oddi = new OperationDataDaoImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action != null && action.equals("add")) {
			addsend(request, response);
		} else if (action != null && action.equals("delete")) {
			delete(request, response);
		} else if (action != null && action.equals("edit")) {
			edit(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void addsend(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("addsend");
		String imgpath = request.getParameter("imgpath");
		System.out.println(imgpath);
		String detail = request.getParameter("detail");
		String name = request.getParameter("name");
		String activetype = request.getParameter("activetype");
		System.out.println("imgpath-------"+imgpath);
		System.out.println("detail-------"+detail);
		System.out.println("name-------"+name);
		System.out.println("activetype-------"+activetype);
		if (imgpath != null && detail != null && name != null && activetype != null && !imgpath.equals("")) {
			System.out.println("11111");
			User user = (User) request.getSession().getAttribute("user");
			int id = 1;
			if (gbdao.getAllData().size() != 0) {
				id = gbdao.getAllData().get(0).getId() + 1;
			} else {
				id = 1;
			}
			int activetypeid = gbdao.getATIdByName(activetype).getId();
			Data data = new Data(id, new Integer(0), imgpath, detail, name, user.getId(), activetypeid);
			VoteSendStatus v = vsdao.getVSS(user.getId(), new Integer(activetypeid));
			if (v != null) {
				System.out.println("3333333333");
				// update
				oddao.addData(data);
				vsdao.amendVSSSend(user.getId(), activetypeid, 1);
			} else {
				System.out.println("44444444444");
				// insert
				oddao.addData(data);
				VoteSendStatus vss = new VoteSendStatus(user.getId(), new Integer(activetypeid), 0, 1);
				vsdao.addVSS(vss);
			}

			request.getRequestDispatcher("GetBasicDataServlet.do?activetypeid=" + activetypeid + "&handler=showdata")
					.forward(request, response);
		} else {
			System.out.println("22222222");
			String msg = "图片错误";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher(
					"OperationJumpServlet.do?opmethod=add&activetypeid=" + gbdao.getATIdByName(activetype).getId())
					.forward(request, response);
			//request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

	protected void delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String activetypename = request.getParameter("activetypename");

		int dataid = Integer.parseInt(request.getParameter("dataid"));
		oddi.delete(dataid);
		User user = (User) request.getSession().getAttribute("user");
		vsdao.amendVSSSend(user.getId(), gbdao.getATIdByName(activetypename).getId(), 0);

		request.getRequestDispatcher("GetBasicDataServlet.do?handler=myselfdata&usertableid=" + user.getId())
				.forward(request, response);
	}

	protected void edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String imgpath = request.getParameter("imgpath");
		String detail = request.getParameter("detail");
		String name = request.getParameter("name");
		String dataid = request.getParameter("dataid");
		Data data = new Data(new Integer(dataid), imgpath, detail, name);
		oddi.edit(data);
		User user = (User) request.getSession().getAttribute("user");
		request.getRequestDispatcher("GetBasicDataServlet.do?handler=myselfdata&usertableid=" + user.getId())
				.forward(request, response);
	}

}
