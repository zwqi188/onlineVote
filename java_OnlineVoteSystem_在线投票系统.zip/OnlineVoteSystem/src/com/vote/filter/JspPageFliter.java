package com.vote.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class JspPageFliter
 */
@WebFilter("/*")
public class JspPageFliter implements Filter {

	/**
	 * Default constructor.
	 */
	public JspPageFliter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletResponse hrResponse = (HttpServletResponse) response;
		HttpServletRequest hrRequest = (HttpServletRequest) request;
		Object user = hrRequest.getSession().getAttribute("user");
		String requestPath = hrRequest.getServletPath();
		if (requestPath.endsWith("login.jsp")
				|| requestPath.endsWith("register.jsp")
				|| requestPath.endsWith("main.jsp")
				|| requestPath.endsWith(".do") || requestPath.endsWith(".css")
				|| requestPath.endsWith(".js") || requestPath.endsWith(".gif")
				|| requestPath.endsWith(".png") || requestPath.endsWith(".jpg")
				|| requestPath.endsWith(".ico")) {

			chain.doFilter(request, response);
		} else if (user != null) {
			chain.doFilter(request, response);
		} else {
			hrResponse.sendRedirect("login.jsp");
		}

	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
