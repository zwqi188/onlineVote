package com.vote.util;

public class PageUtil {
	private int recordCount; // 总记录
	private int prePage; // 上一页
	private int nextPage; // 下一页
	private String url;
	private int currentPage; // 当前页
	private int pageSize; // 每页显示的条数

	public int getPageCount() {
		return recordCount;
	}

	public void setPageCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public int getPrePage() {
		return prePage;
	}

	public void setPrePage(int prePage) {
		this.prePage = prePage;
	}

	public int getNextPage() {
		return nextPage;
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public PageUtil(int recordCount, String url, int currentPage, int pageSize) {
		super();
		this.recordCount = recordCount;
		this.url = url;
		this.currentPage = currentPage;
		this.pageSize = pageSize;
	}

	public PageUtil() {
		super();
	}

	@Override
	public String toString() {
		int pageCount = recordCount/pageSize==0?recordCount/pageSize:(recordCount/pageSize)+1;
		String firstPage = "<a href='"+url+"&page=1'><img src='1/first.png'style='margin-right: 20px;margin-left: 200px;'/></a>";
		String lastPage = "<a href='"+url+"&page="+pageCount+"'><img src='1/last.png'margin-right: 20px;'/></a>";
		String nextP = "";
		if(currentPage == pageCount){
			nextP = "<a><img src='1/next1.png'style='margin-right: 20px;'/></a>";
		}else {
			nextP = "<a href='"+url+"&page="+(currentPage+1)+"'><img src='1/next.png'style='margin-right: 20px;'/></a>";
		}
		String preP = "";
		if(currentPage == 1){
			preP = "<a><img src='1/prev1.png'style='margin-right: 20px;'/></a>";
		}else {
			preP = "<a href='"+url+"&page="+(currentPage-1)+"'><img src='1/prev.png'style='margin-right: 20px;'/></a>";
		}
		
		return firstPage+preP+nextP+lastPage;
	}
}
