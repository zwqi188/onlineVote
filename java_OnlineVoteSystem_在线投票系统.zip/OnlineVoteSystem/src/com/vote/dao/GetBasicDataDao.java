package com.vote.dao;

import java.util.List;

import com.vote.bean.ActiveType;
import com.vote.bean.Data;
import com.vote.bean.ShowData;

public interface GetBasicDataDao {
	//获取所有活动类型
	public List<ActiveType> getAllActiveType();
	//活动类型分页处理
	public List<ActiveType> getAllActiveTypeByPage(int page,int pageSize);
	public int getAllActiveTypeCount();
	
	
	//通过ActiveType  ID  获取datatable 下面所有关于此类活动信息
	public List<ShowData> getShowDataByName(int activetypeid);
	//datatable   分页处理
	public List<ShowData> getShowDataByPage(int activetypeid,int page,int pageSize);
	public int getShowDataCount(int activetypeid);
	
	
	//通过  ID   获取   活动名称
	public ActiveType getATNameById(int activetypeid);
	//通过名称   获得   活动 ID  
	public ActiveType getATIdByName(String name);
	//获取 datatable 表中所有数据 按照降序排列
	public List<Data> getAllData();
	
	//通过  当前用户的  ID   获取  datatable表中    userid  = ID  的所有数据
	public List<ShowData> getShowDataById(int userid);
	//个人中心 分页处理
	public List<ShowData> getmyselfShowDataByPage(int userid,int page,int pageSize);
	public int getmyselfShowDataCount(int userid);
	
	//通过ActiveType  ID  获取datatable 下面所有关于此类活动信息
	public List<ShowData> getShowDataByid(int id);
	
	//活动主界面的  查询
	public List<ActiveType> getFindActiveTypeByPage(String name,int page,int pageSize);
	public int getFindActiveTypeCount(String name);
	//datatable 查询
	public List<ShowData> getFindShowDataByPage(String name,int activetypeid,int page,int pageSize);
	public int getFindShowDataCount(String name,int activetypeid);
	//个人中心查询
	public List<ShowData> getShowDataByidAndName(int userid, String activeName,int page,
			int pageSize);
	public int getmyselfShowAndDataCount(int userid,String activename);
	
	//根据用户id来获取用户所参与投票的活动的信息
	public List<ActiveType> getIsVoteData(int userid);

	
}
