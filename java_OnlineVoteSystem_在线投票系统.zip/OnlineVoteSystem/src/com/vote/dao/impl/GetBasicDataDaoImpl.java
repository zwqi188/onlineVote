package com.vote.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vote.bean.ActiveType;
import com.vote.bean.Data;
import com.vote.bean.ShowData;
import com.vote.dao.GetBasicDataDao;
import com.vote.util.DBUtil;

public class GetBasicDataDaoImpl implements GetBasicDataDao {
	public static void main(String[] args) {
		GetBasicDataDaoImpl g = new GetBasicDataDaoImpl();
		System.out.println(g.getFindShowDataByPage("小", 6, 1, 4));
	}

	@Override
	public List<ActiveType> getAllActiveType() {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select id,name,picture,detail from activetypetable order by id desc";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			List<ActiveType> atList = new ArrayList<ActiveType>();
			while(rs.next()){
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String picture = rs.getString(3);
				String detail = rs.getString(4);
				
				ActiveType at = new ActiveType(id, name, detail, picture);
				atList.add(at);
			}
			return atList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public List<ActiveType> getAllActiveTypeByPage(int page, int pageSize) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql = "select rowno,id,name,picture,detail from "+
					"	(select a.*,rownum as rowno from "+
					"	(select * from activetypetable order by id desc) a) "+
					"	where rowno between ? and ?";
		try {
			PreparedStatement pstmt= conn.prepareStatement(sql);
			pstmt.setInt(1, (page-1)*pageSize+1);
			pstmt.setInt(2, page*pageSize);
			ResultSet rs = pstmt.executeQuery();
			List<ActiveType> atList  = new ArrayList<ActiveType>();
			while(rs.next()){
				int id = rs.getInt(2);
				String name = rs.getString(3) ;
				String picture = rs.getString(4) ;
				String detail = rs.getString(5);
				
				ActiveType at  = new ActiveType();
				at.setId(id);
				at.setDetail(detail);
				at.setName(name);
				at.setPicture(picture);
				
				atList.add(at);
			}
			System.out.println(atList);
			return atList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public int getAllActiveTypeCount() {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql ="select count(*) from activetypetable";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return 0;
	}

	@Override
	public List<ShowData> getShowDataByName(int activetypeid) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select dt.id,dt.votenum,dt.picture,dt.detail,dt.name,ut.name,att.name "+
				     "  from datatable dt"+
				     "  left join usertable ut on dt.userid=ut.id"+
				     "  left join activetypetable att on dt.activetypeid=att.id"+
				     "  where att.id=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, activetypeid);
			ResultSet rs = pstmt.executeQuery();
			List<ShowData> sdList = new ArrayList<ShowData>();
			while(rs.next()){
				int id = rs.getInt(1);
				int votenum = rs.getInt(2);
				String picture = rs.getString(3);
				String detail = rs.getString(4);
				String dataname = rs.getString(5);
				String username = rs.getString(6);
				String atname = rs.getString(7);
				
				ShowData sd = new ShowData(id, votenum, picture, detail,dataname, username, atname);
				sdList.add(sd);
				
			}
			return sdList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public List<ShowData> getShowDataByPage(int activetypeid,int page, int pageSize) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql = "select rowno,i,v,p,d,dn,un,an from "+
					"	(select a.*,rownum as rowno from "+
					"	( "+
					"	select dt.id as i,dt.votenum as v,dt.picture as p,dt.detail as d,dt.name as dn,ut.name as un,att.name as an "+
					"	               from datatable dt "+
					"	              left join usertable ut on dt.userid=ut.id "+
					"					       left join activetypetable att on dt.activetypeid=att.id "+
					"					       where att.id=? "+
					"	) a) "+
					"	where rowno between ? and ?";
		try {
			PreparedStatement pstmt= conn.prepareStatement(sql);
			pstmt.setInt(1, activetypeid);
			pstmt.setInt(2, (page-1)*pageSize+1);
			pstmt.setInt(3, page*pageSize);
			ResultSet rs = pstmt.executeQuery();
			List<ShowData> sdList  = new ArrayList<ShowData>();
			while(rs.next()){
				int id = rs.getInt(2);
				int votenum = rs.getInt(3);
				String picture = rs.getString(4);
				String detail = rs.getString(5);
				String dataname = rs.getString(6);
				String username = rs.getString(7);
				String atname = rs.getString(8);
				
				ShowData sd = new ShowData(id, votenum, picture, detail,dataname, username, atname);
				
				sdList.add(sd);
			}
			//System.out.println(sdList);
			return sdList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}
	
	@Override
	public int getShowDataCount(int activetypeid) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql ="select count(*) from datatable where activetypeid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, activetypeid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return 0;
	}
	
	@Override
	public ActiveType getATNameById(int activetypeid) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql ="select id,name,picture,detail from activetypetable where id=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, activetypeid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				String name = rs.getString(2);
				String picture = rs.getString(3);
				String detail = rs.getString(4);
				
				ActiveType at = new ActiveType(activetypeid, name, detail, picture);
				
				return at;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public ActiveType getATIdByName(String name) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql ="select id,name,picture,detail from activetypetable where name=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				int id = rs.getInt(1);
				String picture = rs.getString(3);
				String detail = rs.getString(4);
				
				ActiveType at = new ActiveType(id, name, detail, picture);
				
				return at;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public List<Data> getAllData() {
		DBUtil util = new DBUtil();	
		Connection conn = util.openConnection();
		String sql ="select id,votenum,picture,detail,name,userid,activetypeid from datatable order by id desc";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			List<Data>  dataList = new ArrayList<Data>();
			while(rs.next()){
				int id = rs.getInt(1);
				int votenum = rs.getInt(2);
				String picture = rs.getString(3);
				String detail = rs.getString(4);
				String name = rs.getString(5);
				int userid = rs.getInt(6);
				int activetypeid = rs.getInt(7);
				
				Data data = new Data(id, votenum, picture, detail, name, userid, activetypeid);
				
				dataList.add(data);
			}
			
			return dataList;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}
	
	@Override
	public List<ShowData> getShowDataById(int userid) { 
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select dt.id,dt.votenum,dt.picture,dt.detail,dt.name,ut.name,att.name "+
				     "  from datatable dt"+
				     "  left join usertable ut on dt.userid=ut.id"+
				     "  left join activetypetable att on dt.activetypeid=att.id"+
				     "  where ut.id=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userid);
			ResultSet rs = pstmt.executeQuery();
			List<ShowData> sdList = new ArrayList<ShowData>();
			while(rs.next()){
				int id = rs.getInt(1);
				int votenum = rs.getInt(2);
				String picture = rs.getString(3);
				String detail = rs.getString(4);
				String dataname = rs.getString(5);
				String username = rs.getString(6);
				String atname = rs.getString(7);
				
				ShowData sd = new ShowData(id, votenum, picture, detail,dataname, username, atname);
				sdList.add(sd);
				
			}
			return sdList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public List<ShowData> getmyselfShowDataByPage(int userid, int page, int pageSize) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql = "select rowno,i,v,p,d,dn,un,an from "+
					"	(select a.*,rownum as rowno from "+
					"	( "+
					"	select dt.id as i,dt.votenum as v,dt.picture as p,dt.detail as d,dt.name as dn,ut.name as un,att.name as an "+
					"	               from datatable dt "+
					"	              left join usertable ut on dt.userid=ut.id "+
					"					       left join activetypetable att on dt.activetypeid=att.id "+
					"					       where ut.id=? "+
					"	) a) "+
					"	where rowno between ? and ?";
		try {
			PreparedStatement pstmt= conn.prepareStatement(sql);
			pstmt.setInt(1, userid);
			pstmt.setInt(2, (page-1)*pageSize+1);
			pstmt.setInt(3, page*pageSize);
			ResultSet rs = pstmt.executeQuery();
			List<ShowData> sdList  = new ArrayList<ShowData>();
			while(rs.next()){
				int id = rs.getInt(2);
				int votenum = rs.getInt(3);
				String picture = rs.getString(4);
				String detail = rs.getString(5);
				String dataname = rs.getString(6);
				String username = rs.getString(7);
				String atname = rs.getString(8);
				
				ShowData sd = new ShowData(id, votenum, picture, detail,dataname, username, atname);
				
				sdList.add(sd);
			}
			return sdList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public int getmyselfShowDataCount(int userid) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql ="select count(*) from datatable where userid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return 0;
	}

	@Override
	public List<ShowData> getShowDataByid(int id) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select dt.id,dt.votenum,dt.picture,dt.detail,dt.name,ut.name,att.name "+
				     "  from datatable dt"+
				     "  left join usertable ut on dt.userid=ut.id"+
				     "  left join activetypetable att on dt.activetypeid=att.id"+
				     "  where dt.id=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			List<ShowData> sdList = new ArrayList<ShowData>();
			while(rs.next()){
				int votenum = rs.getInt(2);
				String picture = rs.getString(3);
				String detail = rs.getString(4);
				String dataname = rs.getString(5);
				String username = rs.getString(6);
				String atname = rs.getString(7);
				
				ShowData sd = new ShowData(id, votenum, picture, detail,dataname, username, atname);
				sdList.add(sd);
				
			}
			return sdList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}		
		return null;
	}

	@Override
	public List<ActiveType> getFindActiveTypeByPage(String name,int page, int pageSize) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql = "select rowno,id,name,picture,detail from "+
					"	(select a.*,rownum as rowno from "+
					"	(select * from activetypetable where name like ? order by id desc) a) "+
					"	where rowno between ? and ?";
		try {
			PreparedStatement pstmt= conn.prepareStatement(sql);
			pstmt.setString(1, "%"+name+"%");
			pstmt.setInt(2, (page-1)*pageSize+1);
			pstmt.setInt(3, page*pageSize);
			ResultSet rs = pstmt.executeQuery();
			List<ActiveType> atList  = new ArrayList<ActiveType>();
			while(rs.next()){
				int id = rs.getInt(2);
				String atname = rs.getString(3) ;
				String picture = rs.getString(4) ;
				String detail = rs.getString(5);
				
				ActiveType at  = new ActiveType();
				at.setId(id);
				at.setDetail(detail);
				at.setName(atname);
				at.setPicture(picture);
				
				atList.add(at);
			}
			System.out.println(atList);
			return atList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public int getFindActiveTypeCount(String name) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql ="select count(*) from activetypetable where name like ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+name+"%");
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return 0;
	}

	@Override
	public List<ShowData> getFindShowDataByPage(String name,int activetypeid,int page,int pageSize) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql = "select rowno,i,v,p,d,dn,un,an from "+
					"	(select a.*,rownum as rowno from "+
					"	( "+
					"	select dt.id as i,dt.votenum as v,dt.picture as p,dt.detail as d,dt.name as dn,ut.name as un,att.name as an "+
					"	               from datatable dt "+
					"	              left join usertable ut on dt.userid=ut.id "+
					"					       left join activetypetable att on dt.activetypeid=att.id "+
					"					       where att.id=? and dt.name like ? "+
					"	) a) "+
					"	where rowno between ? and ?";
		try {
			PreparedStatement pstmt= conn.prepareStatement(sql);
			pstmt.setInt(1, activetypeid);
			pstmt.setString(2, "%"+name+"%");
			pstmt.setInt(3, (page-1)*pageSize+1);
			pstmt.setInt(4, page*pageSize);
			ResultSet rs = pstmt.executeQuery();
			List<ShowData> sdList  = new ArrayList<ShowData>();
			while(rs.next()){
				int id = rs.getInt(2);
				int votenum = rs.getInt(3);
				String picture = rs.getString(4);
				String detail = rs.getString(5);
				String dataname = rs.getString(6);
				String username = rs.getString(7);
				String atname = rs.getString(8);
				
				ShowData sd = new ShowData(id, votenum, picture, detail,dataname, username, atname);
				
				sdList.add(sd);
			}
			//System.out.println(sdList);
			return sdList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public int getFindShowDataCount(String name, int activetypeid) {
		DBUtil util =new DBUtil();
		Connection conn =util.openConnection();
		String sql ="select count(*) from datatable where activetypeid=? and name like ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, activetypeid);
			pstmt.setString(2, "%"+name+"%");
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return 0;
	}

	@Override
	public List<ShowData> getShowDataByidAndName(int userid, String activeName, int page, int pageSize) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select rowno,i,v,p,d,dn,un,an from "
				+ "	(select a.*,rownum as rowno from "
				+ "	( "
				+ "	select dt.id as i,dt.votenum as v,dt.picture as p,dt.detail as d,dt.name as dn,ut.name as un,att.name as an "
				+ "	               from datatable dt "
				+ "	              left join usertable ut on dt.userid=ut.id "
				+ "					       left join activetypetable att on dt.activetypeid=att.id "
				+ "					       where ut.id=? and dt.name like ? "
				+ "	) a) " + "	where rowno between ? and ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userid);
			pstmt.setString(2, "%"+activeName+"%");
			pstmt.setInt(3, (page - 1) * pageSize + 1);
			pstmt.setInt(4, page * pageSize);
			ResultSet rs = pstmt.executeQuery();
			List<ShowData> sdList = new ArrayList<ShowData>();
			while (rs.next()) {
				int id = rs.getInt(2);
				int votenum = rs.getInt(3);
				String picture = rs.getString(4);
				String detail = rs.getString(5);
				String dataname = rs.getString(6);
				String username = rs.getString(7);
				String atname = rs.getString(8);

				ShowData sd = new ShowData(id, votenum, picture, detail,
						dataname, username, atname);

				sdList.add(sd);

			}
			return sdList;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public int getmyselfShowAndDataCount(int userid, String activename) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select count(*)  from datatable dt  left join usertable ut on dt.userid=ut.id left join activetypetable att on dt.activetypeid=att.id   where ut.id=? and dt.name like ?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userid);
			pstmt.setString(2, "%"+activename+"%");
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return 0;
	}
	
	@Override
	public List<ActiveType> getIsVoteData(int userid) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql ="select att.picture,att.detail "
				+ "from activetypetable att left join votesendstatustable"
				+ " asst on att.id=asst.activetypeid "
				+ "where asst.isvote=1 and asst.userid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userid);
			ResultSet rs = pstmt.executeQuery();
			List<ActiveType> AtList = new ArrayList<ActiveType>();
			while(rs.next()){
				String picture = rs.getString(1);
				String detail = rs.getString(2);
				
				ActiveType at = new ActiveType(detail,picture);
				AtList.add(at);
				
			}
			return AtList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}		
		return null;
	}


}
