package com.vote.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.vote.bean.Data;
import com.vote.dao.OperationDataDao;
import com.vote.util.DBUtil;

public class OperationDataDaoImpl implements OperationDataDao {

	@Override
	public void addData(Data data) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "insert into datatable(id,votenum,picture,detail,name,userid,activetypeid) values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, data.getId());
			pstmt.setInt(2, data.getVotenum());
			pstmt.setString(3, data.getPicture());
			pstmt.setString(4, data.getDetail());
			pstmt.setString(5, data.getName());
			pstmt.setInt(6, data.getUserid());
			pstmt.setInt(7, data.getActivetypeid());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
	}
	
	@Override
	public void delete(int dataid) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql1 = "delete from datatable where datatable.id=?";
		
//		String sql2 = "update votesendstatustable "
//				+ "set votesendstatustable.issend =0 "
//				+ "where votesendstatustable.userid = (select datatable.userid from datatable where datatable.id = ?) "
//				+ "and votesendstatustable.activetypeid = (select datatable.activetypeid from datatable where datatable.id = ?) ";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql1);
			pstmt.setInt(1, dataid);
			pstmt.executeQuery();
			
//			PreparedStatement pstmt1 = conn.prepareStatement(sql2);
//			pstmt1.setInt(1, dataid);
//			pstmt1.setInt(2, dataid);
//			
//			pstmt1.executeQuery();
//		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		
	}

	@Override
	public void edit(Data data) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "update datatable set picture=?,detail=?,name=? where id=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, data.getPicture());
			pstmt.setString(2, data.getDetail());
			pstmt.setString(3, data.getName());
			pstmt.setInt(4, data.getId());

			pstmt.executeQuery();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		
		
	}

}
