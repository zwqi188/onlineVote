package com.vote.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.vote.bean.VoteSendStatus;
import com.vote.dao.VoteSendDao;
import com.vote.util.DBUtil;

public class VoteSendDaoImpl implements VoteSendDao {

	@Override
	public List<VoteSendStatus> getAllVSS() {

		return null;
	}

	@Override
	public VoteSendStatus getVSS(int userid, int activetypeid) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select userid,activetypeid,isvote,issend from votesendstatustable where userid=? and activetypeid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userid);
			pstmt.setInt(2, activetypeid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				int isvote = rs.getInt(3);
				int issend = rs.getInt(4);
				VoteSendStatus vss = new VoteSendStatus(userid, activetypeid, isvote, issend);
				
				return vss;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}

		return null;
	}

	@Override
	public void addVSS(VoteSendStatus vss) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "insert into votesendstatustable(userid,activetypeid,isvote,issend)values(?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vss.getUserid());
			pstmt.setInt(2, vss.getActivetypeid());
			pstmt.setInt(3, vss.getIsvote());
			pstmt.setInt(4, vss.getIssend());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
	}


	@Override
	public void amendDataVoteNum(int dataid) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "update datatable set votenum=votenum+1 where id=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dataid);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
	}

	@Override
	public void amendVSSVote(int userid, int activetypeid, int isvote) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "update votesendstatustable set isvote=? where userid=? and activetypeid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, isvote);
			pstmt.setInt(2, userid);
			pstmt.setInt(3, activetypeid);
			pstmt.executeUpdate();
			//System.out.println("update isvote");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		
	}

	@Override
	public void amendVSSSend(int userid, int activetypeid, int issend) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "update votesendstatustable set issend=? where userid=? and activetypeid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, issend);
			pstmt.setInt(2, userid);
			pstmt.setInt(3, activetypeid);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		
	}

}
