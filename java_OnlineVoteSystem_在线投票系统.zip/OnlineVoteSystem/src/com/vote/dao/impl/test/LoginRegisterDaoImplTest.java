package com.vote.dao.impl.test;

import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.vote.bean.User;
import com.vote.dao.LoginRegisterDao;
import com.vote.dao.impl.LoginRegisterDaoImpl;

public class LoginRegisterDaoImplTest {
	LoginRegisterDao lrdao = null;
	@Before
	public void setUp() throws Exception {
		lrdao = new LoginRegisterDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

//	@Test
//	public void testLogin() {
//		User user = lrdao.login("nigel", "123000");
//		System.out.println(user);
//	}

//	@Test
//	public void testRegister() {
//		User user = new User(1, "nigel", "123000", "1454900516@qq.com");
//		lrdao.register(user);
//	}
//
//	@Test
//	public void testCheck() {
//		boolean flag = lrdao.check("nigel");
//		System.out.println(flag);
//	}
	@Test
	public void testGetAllUser() {
		List<User> userlist = lrdao.getAllUser();
		Iterator<User> it = userlist.iterator();
		while(it.hasNext()){
			User user = it.next();
			System.out.println(user.getId());
		}
	}

}
