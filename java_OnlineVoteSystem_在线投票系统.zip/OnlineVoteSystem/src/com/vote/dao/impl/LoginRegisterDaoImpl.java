package com.vote.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vote.bean.User;
import com.vote.dao.LoginRegisterDao;
import com.vote.util.DBUtil;

public class LoginRegisterDaoImpl implements LoginRegisterDao {

	@Override
	public User login(String name, String password) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select id,name,password,email from usertable where name=? and password=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int userid = rs.getInt(1);
				String username = rs.getString(2);
				String userpassword = rs.getString(3);
				String useremail = rs.getString(4);

				User user = new User(userid, username, userpassword, useremail);

				return user;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}

	@Override
	public void register(User user) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "insert into usertable(id,name,password,email)values(?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, user.getId());
			pstmt.setString(2, user.getName());
			pstmt.setString(3, user.getPassword());
			pstmt.setString(4, user.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
	}

	@Override
	public boolean check(String name) {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		String sql = "select * from usertable where name=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				// 该用户已经存在
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		// 该用户不存在
		return false;
	}

	@Override
	public List<User> getAllUser() {
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		//降序   去最大的   保证主键不重复
		String sql = "select id,name,password,email from usertable order by id desc";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			List<User> userList = new ArrayList<User>();
			while(rs.next()){
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String password = rs.getString(3);
				String email = rs.getString(4);
				
				User user = new User(id, name, password, email);
				userList.add(user);
			}
			return userList;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			util.closeConnection(conn);
		}
		return null;
	}
}
