package com.vote.dao;

import com.vote.bean.Data;

public interface OperationDataDao {
	//发布数据  添加到   datatable  表
	public void addData(Data data);
	
	//根据usertable id 和 activitytype id 获取到用户的信息，然后删除
	public void delete (int dataid);
	
	//编辑操作
	public void edit(Data data); 
}
