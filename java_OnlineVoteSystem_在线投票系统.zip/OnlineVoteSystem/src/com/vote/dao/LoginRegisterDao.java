package com.vote.dao;

import java.util.List;

import com.vote.bean.User;

public interface LoginRegisterDao {
	//用户登录
	public User login(String name,String password);
	//用户注册
	public void register(User user);
	//用户注册时  检查用户名是否存在
	public boolean check(String name);
	//获取所有用户   在注册是分配id
	public List<User> getAllUser();
}
