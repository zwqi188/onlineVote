package com.vote.dao;

import java.util.List;

import com.vote.bean.VoteSendStatus;

public interface VoteSendDao {
	//在投票与发送之前判断该用户有没有参与投票或者发送
	public List<VoteSendStatus> getAllVSS();
	public VoteSendStatus getVSS(int userid,int activetypeid);
	//给状态表中添加数据
	public void addVSS(VoteSendStatus vss);
	//更新状态表中的状态  投票
	public void amendVSSVote(int userid,int activetypeid,int isvote);
	//更新状态表中的状态  发布
	public void amendVSSSend(int userid,int activetypeid,int issend);
	//更新数据表中的   votenum  票数
	public void amendDataVoteNum(int dataid);
}
